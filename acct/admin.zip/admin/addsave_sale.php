<?php
	require_once '../conn.php';
	
if (isset($_POST['save'])) {
    	if(ISSET($_POST['item'])){
	    
    
extract($_POST);	    
$scode = $_POST['scode'];
$today = date('Y-m-d');
$query1= mysqli_query($conn, "INSERT INTO `confirmedsales`(`SaleCode`, `TotalAmt`, `Customer`, `PaidAmt`, `Balance`, `DateConfirmed`, `SBlocation`, `User`) VALUES ('$scode','$toto', '$customer', '$paid', '$balance', '$today', '$SaleLocation','$me') ");
$result1 = mysqli_query($conn,"UPDATE `sale` SET State = 'Saved', Updateby ='$me' WHERE Scode = '$scode' AND SaleLocation ='$SaleLocation' ");
    if($conn->affected_rows > 0){     
	    
	    
    	echo '<script language="javascript">';
                                        echo 'alert("Sale Successfully Added,!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=newsale?scode='.("S-".uniqid().time().date("Ymd") ).'" />';
    

		}
		
		     else {
$er = $conn->error;
	 echo '<script language="javascript">';
                                        echo 'alert("OOOH NOO SvO2! '.$er.'")';
                                        echo '</script>';
                                        echo "<script type='text/javascript'>window.history.go(-1);</script>";
    
}
		
	}
} else if (isset($_POST['sprnt'])) {
   	if(ISSET($_POST['item'])){
	    
extract($_POST);	    
$scode = $_POST['scode'];
$today = date('Y-m-d');
$query1= mysqli_query($conn, "INSERT INTO `confirmedsales`(`SaleCode`, `TotalAmt`, `Customer`, `PaidAmt`, `Balance`, `DateConfirmed`, `SBlocation`, `User`) VALUES ('$scode','$toto', '$customer', '$paid', '$balance', '$today', '$SaleLocation','$me') ");
		$result1 = mysqli_query($conn,"UPDATE `sale` SET State = 'Saved', Updateby ='$me' WHERE Scode = '$scode' AND SaleLocation ='$SaleLocation' ");
    if($conn->affected_rows > 0){     
	    
										echo '<script language="javascript">';
                                        echo 'alert("Sale Successfully Added,!")';
                                        echo '</script>';
                                        echo '<meta http-equiv="refresh" content="0;url=newsale?scode='.("S-".uniqid().time().date("Ymd") ).'" />';
    

		}
		
		     else {
$er = $conn->error;
	 echo '<script language="javascript">';
                                        echo 'alert("OOOH NOO EO2! '.$er.'")';
                                        echo '</script>';
                                        echo "<script type='text/javascript'>window.history.go(-1);</script>";
    
}
		
	}
} else {
   $er = $conn->error;
	 echo '<script language="javascript">';
                                        echo 'alert("OOOH NOO EO2! Could not update state '.$er.'")';
                                        echo '</script>';
                                        echo "<script type='text/javascript'>window.history.go(-1);</script>";
}	
	

?>


// <?php

// include "../conn.php";
// extract($_POST);
// $today = date("Y-m-d");
// $item = $_POST['item'];
// $qty = $_POST['qty'];
// 	for($i=0;$i<count($item);$i++){
// 	$items = $item[$i]; 
//     $qty = $qty[$i]; 

// $result = mysqli_query($conn,"UPDATE `stock` SET Stock = Stock-'$qty'  WHERE Pdt = '$items' ");

// }
// if ( $result -> affected_rows > 0) {
//     $sql2 = "UPDATE `sale` SET State = 'Saved', Updateby ='$me'
//  WHERE `sale`.`Scode` = '$scode' AND State = 'Pending' ";

// if ($conn->query($sql2) === TRUE) {
	
//  echo '<script language="javascript">';
//                                         echo 'alert("User Successfully Added,!")';
//                                         echo '</script>';
//                                         echo '<meta http-equiv="refresh" content="0;url=users" />';
   
// } 
// }

// else {

// 	 echo '<script language="javascript">';
//                                         echo 'alert("User name or Email already taken!")';
//                                         echo '</script>';
//      echo $conn->error;
//           echo '<form>
//  <input type="button" value="Go back!" onclick="history.back()">
// </form>';
// }

// $conn->close();

// ?>